/*
NOM :
Prénom :

NOM :
Prénom :

*/

function alea(min, max){ // [0;15[
  return Math.floor((Math.random()*(max-min))+min)
}
